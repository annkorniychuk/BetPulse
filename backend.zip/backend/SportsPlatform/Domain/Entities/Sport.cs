namespace SportsPlatform.Domain.Entities;

public class Sport
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
}
